//
//  Set.h
//  project2
//
//  Created by SunYutong on 4/22/17.
//  Copyright © 2017 SunYutong. All rights reserved.
//

#ifndef Set_h
#define Set_h

#include <string>
using namespace std;



typedef std::string ItemType;

class Set
{
public:
    Set();
    bool empty() const;
    int size() const;
    bool insert(const ItemType& value);
    bool erase(const ItemType& value);
    bool contains(const ItemType& value) const;
    bool get(int pos, ItemType& value) const;
    void swap(Set& other);
//    void dump() const;
    
    ~Set();
    Set(const Set& other);
    Set& operator=(const Set& rhs);
    
private:
   
    //   a circular doubly-linked list with a dummy node.
    struct Node
    {
        ItemType m_data;
        Node*    m_next;
        Node*    m_prev;
    };
    
    Node* m_head;
    int   m_size;
    
    void createEmpty();
    // Create an empty list.  (Should be called only by constructors.)
    
    void insertBefore(Node* p, const ItemType& value);
    // Insert value in a new Node before Node p, incrementing m_size.
    
    Node* doErase(Node* p);
    // Remove the Node p, decrementing m_size.  Return the Node that
    // followed p.
    
    Node* nodeAtPos(int pos) const;
    // Return pointer to Node at position pos.  Work for the get function
    //to get the m_data at pos

};

//Set algorithms
void unite(const Set& s1, const Set& s2, Set& result);
void subtract(const Set& s1, const Set& s2, Set& result);

inline
int Set::size() const
{
    return m_size;
}

inline
bool Set::empty() const
{
    return size() == 0;
}


#endif /* Set_h */
