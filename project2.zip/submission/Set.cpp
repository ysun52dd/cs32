//
//  Set.cpp
//  project2
//
//  Created by SunYutong on 4/22/17.
//  Copyright © 2017 SunYutong. All rights reserved.
//

#include "Set.h"

Set::Set()
{
    createEmpty();
}

Set::~Set()
{
    // Delete all Nodes from first non-dummy up to but not including
    // the dummy
    
    while (m_head->m_next != m_head)
        doErase(m_head->m_next);
    
    // Delete the dummy
    
    delete m_head;
}

Set::Set(const Set& other)
{
    createEmpty();
    
    // Copy all non-dummy other Nodes.  (This sets m_size.)
    // Inserting each new node before the dummy node that m_head points to
    // puts the new node at the end of the list.
    
    for (Node* p = other.m_head->m_next; p != other.m_head; p = p->m_next)
        insertBefore(m_head, p->m_data);
}

Set& Set::operator=(const Set& rhs)
{
    if (this != &rhs)
    {
        Set temp(rhs);
        swap(temp);
    }
    return *this;
}

bool Set::insert(const ItemType& value)
{
    // Find the Node before which to insert
    Node* p;
    int pos;
    for (p = m_head->m_next, pos = 0; p != m_head  &&
         value > p->m_data; p = p->m_next, pos++)
        ;
        if(pos<m_size && p->m_data==value)
            return false;
    
    
    // Insert the value there
    insertBefore(p, value);
    return true;
}

bool Set::erase(const ItemType& value)
{
    Node* p;
    int pos;
    for (p = m_head->m_next, pos = 0; p != m_head  &&
         value > p->m_data; p = p->m_next, pos++)
        ;
    if (pos == m_size  ||  p->m_data != value) //didn't find value until the end of
                                               //linked list
        return false;
    doErase(p);
    return true;

}
bool Set::contains(const ItemType& value) const
{
    Node* p;
    int pos;
    for (p = m_head->m_next, pos = 0; p != m_head  &&
        p->m_data != value; p = p->m_next, pos++)
        ;
   
    return pos < m_size  &&  p->m_data == value;
    

}
bool Set::get(int pos, ItemType& value) const
{
    if (pos < 0  ||  pos >= m_size)
        return false;
    
    Node* p = nodeAtPos(pos);
    value = p->m_data;
    
    return true;
}

void Set::swap(Set& other)
{
    
    // Swap head pointers
    
    Node* p = m_head;
    m_head = other.m_head;
    other.m_head = p;

    // Swap sizes

    int tempSize = m_size;
    m_size = other.m_size;
    other.m_size = tempSize;
}



void Set::createEmpty()
{
    m_size=0;
    
    m_head = new Node;//create a new Node
    m_head->m_next=m_head;
    m_head->m_prev=m_head;
}

void Set::insertBefore(Node* p, const ItemType& value)
{
    // Create a new node with value
    
    Node* newp = new Node;
    newp->m_data = value;
    
    // Insert new item before p
    
    newp->m_prev = p->m_prev;
    newp->m_next = p;
    newp->m_prev->m_next = newp;
    newp->m_next->m_prev = newp;
    
    m_size++;
}


Set::Node* Set::doErase(Node* p)
{
    Node* pnext=p->m_next;//save pointer to p's successor
    
    p->m_prev->m_next=p->m_next;
    p->m_next->m_prev=p->m_prev;
    delete p;
    
    m_size--;
    return pnext;
}


Set::Node* Set::nodeAtPos(int pos) const
{
    Node* p;
    
    // If pos is closer to the head of the list, go forward from the head to find it.
    // Otherwise, start from tail and go backward.
    
    if (pos <= m_size / 2)  // closer to head
    {
        p = m_head->m_next;
        for (int k = 0; k != pos; k++)
            p = p->m_next;
    }
    else  // closer to tail
    {
        p = m_head;
        for (int k = m_size; k != pos; k--)
            p = p->m_prev;
    }
    
    return p;
}




//Set algorithms

void unite(const Set& s1, const Set& s2, Set& result)
{
    //if result and s1 have the same reference
    if(&result==&s1  )
    {
        ItemType x;
        int tempsize2=s2.size();
        for(int i=0; i<tempsize2; i++)
        {
            
            
            s2.get(i, x);
            result.insert(x);
        }
    }
    //if result and s2 have the same reference
    else if(&result==&s2)
    {
        ItemType y;
        int tempsize1=s1.size();
        for(int i=0; i<tempsize1; i++)
        {
            
            
            s1.get(i, y);
            
            result.insert(y);
        }

    }

    else
    {
    //clean result if it is not empty
    if(!result.empty())
    {
        ItemType v;
        int tempsize=result.size();
        for(int i=0; i<tempsize; i++)
        {
            
            result.get(0, v);
            result.erase(v);
        }
    }
    //loop to insert elements in s1 and s2 into result
    ItemType data1;
    ItemType data2;
    for (int k=0; k<s1.size(); k++)
    {
        for(int i=0; i<s2.size(); i++)
        {
            
            
            s1.get(k, data1);
            s2.get(i, data2);
            result.insert(data1);
            result.insert(data2);
        }
    }
    
    }
    
}
void subtract(const Set& s1, const Set& s2, Set& result)
{
    //if reuslt and s1 have the same reference
    //do not clean result and call erase fucntion for s1
    //to erase all elements in s2
    if(&result==&s1  )
    {
        ItemType m;
        int tempsize2=s2.size();
        for(int i=0; i<tempsize2; i++)
        {
            
            
            s2.get(i, m);
            
            result.erase(m);
        }
    }
    
    //if result and s2 have the same reference
    //do not clean result, declare a new set, temp, to hold the result and call
    //erase function for temp to erase all elements in s2
    //set result to temp
    else if(&result==&s2)
    {
        ItemType n;
        Set temp=s1;
        int tempsize2=s2.size();
        for(int i=0; i<tempsize2; i++)
        {
            
            
            s2.get(i, n);
            
            temp.erase(n);
        }
        result=temp;
    }
    

    
    else{
    //if result is not empty, clean result first
    if(!result.empty())
    {
        ItemType v;
        int tempsize=result.size();
        for(int i=0; i<tempsize; i++)
        {
            
            result.get(0, v);
            result.erase(v);
        }
    }

    ItemType data2;
    result=s1;
    for(int i=0; i<s2.size(); i++)
    {
            

        s2.get(i, data2);
            
        result.erase(data2);
    }
    
    }
}

