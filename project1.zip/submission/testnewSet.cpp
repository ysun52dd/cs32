//
//  testnewSet.cpp
//  hw1
//
//  Created by SunYutong on 4/16/17.
//  Copyright © 2017 SunYutong. All rights reserved.

#include "newSet.h"
#include <iostream>
#include <cassert>
using namespace std;


void test()
{



        Set uls;
        assert(uls.insert(20));
        assert(uls.insert(10));
        assert(uls.size() == 2);
        assert(uls.contains(10));
        ItemType x ;
        assert(uls.get(0, x)  &&  x == 10);
        assert(uls.get(1, x)  &&  x == 20);
        //Assignment operator
        Set uls2;
        uls2=uls;
        assert(uls2.contains(10)&&uls2.contains(20)&&uls2.size()==2);
        //Copy constructor
        Set uls3(uls2);
        assert(uls3.contains(10)&&uls3.contains(20)&&uls3.size()==2);
        assert(uls.get(1, x)  &&  x == 20);
    
        Set ss;
        ss.insert(100);
        ss.insert(200);
        ss.insert(300);
        ss.insert(400);
        ss.insert(200);
        ss.insert(300);
        ss.insert(500);
        assert(ss.size() == 5);
        ItemType y;
        ss.get(0, y);
        assert(y == 100);  // "chapati" is greater than exactly 0 items in ss
        ss.get(4, y);
        assert(y == 500);  // "roti" is greater than exactly 4 items in ss
        ss.get(2, y);
        assert(y == 300);  // "lavash" is greater than exactly 2 items in ss
        
        Set ss3;
        ss3.insert(666);
        assert(!ss3.contains(0));
        ss3.insert(0);
        ss3.insert(1);
        ss3.insert(3);
        assert(ss3.contains(0));
        ss3.erase(3);
        assert(ss3.size() == 3  &&  ss3.contains(666)  &&  ss3.contains(0)  &&
               ss3.contains(1));
        ItemType v;
        assert(ss3.get(1, v)  &&  v == 1);
        assert(ss3.get(0, v)  &&  v == 0);
        Set ss1;
        ss1.insert(10);
        Set ss2;
        ss2.insert(20);
        ss2.insert(300);
        ss1.swap(ss2);
        assert(ss1.size() == 2  &&  ss1.contains(300)  &&  ss1.contains(20)  &&
               ss2.size() == 1  &&  ss2.contains(10));
        

}

int main()
{
    test();
    cout << "Passed all tests" << endl;
}
