//
//  testSSNSet.cpp
//  hw1
//
//  Created by SunYutong on 4/16/17.
//  Copyright © 2017 SunYutong. All rights reserved.
//


#include "Set.h"
#include "SSNSet.h"
#include <iostream>
#include <string>
#include <cassert>
using namespace std;


int main()
{
    SSNSet s;
    
    ItemType x = 9876543;
    s.add(123456789);
    
    assert(s.size()==1);
    assert(s.add(x));
    assert(s.size()==2);
    
    assert(s.add(876543210));
    assert(s.size()==3);
    
    assert(s.add(8143847113));
    assert(!s.add(x));
    s.print();
    cout<<endl;
    
    
    SSNSet s2;
    s2.print();
    cout<<endl;
    
    //Assignment operator
    SSNSet s3=s;
    s3.print();
    cout<<endl;
    //Copy constructor
    SSNSet s4(s);
    s4.print();
    cout<<endl;
    
    
    
    
    cout << "Passed all tests" << endl;
}
