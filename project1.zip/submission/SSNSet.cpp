//
//  SSNSet.cpp
//  hw1
//
//  Created by SunYutong on 4/16/17.
//  Copyright © 2017 SunYutong. All rights reserved.
//

#include <iostream>

#include "SSNSet.h"
#include "Set.h"

SSNSet::SSNSet()
{}

bool SSNSet::add(ItemType ssn)
{
    
    return m_ssn.insert(ssn);
}

void SSNSet::print() const
{
    for(int i=0; i<size(); i++)
    {
        ItemType printSsn;
        m_ssn.get(i, printSsn);
        std::cout<<printSsn<<endl;
        
    }
        
}

int SSNSet::size() const
{
    return m_ssn.size();
}
