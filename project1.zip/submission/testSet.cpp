//
//  testSet.cpp
//  hw1
//
//  Created by SunYutong on 4/12/17.
//  Copyright © 2017 SunYutong. All rights reserved.
//


#include "Set.h"
#include <iostream>
#include <string>
#include <cassert>
using namespace std;


//int main()
//{
//    Set s;
//    assert(s.empty());
//    ItemType x = 9876543;
//    assert( !s.get(42, x)  &&  x == 9876543); // x unchanged by get failure
//    s.insert(123456789);
//    assert(s.size() == 1);
//    assert(s.get(0, x)  &&  x == 123456789);
//    cout << "Passed all tests" << endl;
//}

void test()
{
    Set uls;
    assert(uls.insert(20));
    assert(uls.insert(10));
    assert(uls.size() == 2);
    assert(uls.contains(10));
    ItemType x = 30;
    assert(uls.get(0, x)  &&  x == 10);
    assert(uls.get(1, x)  &&  x == 20);
    //Assignment operator
    Set uls2;
    uls2=uls;
    assert(uls2.contains(10)&&uls2.contains(20)&&uls2.size()==2);
    //Copy constructor
    Set uls3(uls2);
    assert(uls3.contains(10)&&uls3.contains(20)&&uls3.size()==2);
    
    Set ss;
    assert(ss.empty());
    
    ss.insert(100);
    ss.insert(200);
    ss.insert(300);
    ss.insert(400);
    ss.insert(200);
    ss.insert(300);
    ss.insert(500);
    assert(ss.size() == 5);
    ItemType y;
    ss.get(0, y);
    assert(y == 100);  // "chapati" is greater than exactly 0 items in ss
    ss.get(4, y);
    assert(y == 500);  // "roti" is greater than exactly 4 items in ss
    ss.get(2, y);
    assert(y == 300);  // "lavash" is greater than exactly 2 items in ss

    Set ss3;
    ss3.insert(666);
    assert(!ss3.contains(0));
    ss3.insert(0);
    ss3.insert(1);
    ss3.insert(3);
    assert(ss3.contains(0));
    ss3.erase(3);
    assert(ss3.size() == 3  &&  ss3.contains(666)  &&  ss3.contains(0)  &&
           ss3.contains(1));
    ItemType v;
    assert(ss3.get(1, v)  &&  v == 1);
    assert(ss3.get(0, v)  &&  v == 0);
    Set ss1;
    ss1.insert(10);
    Set ss2;
    ss2.insert(20);
    ss2.insert(300);
    ss1.swap(ss2);
    assert(ss1.size() == 2  &&  ss1.contains(300)  &&  ss1.contains(20)  &&
           ss2.size() == 1  &&  ss2.contains(10));
    Set ss4;
    assert(ss4.empty());
    for (int i = 0; i < DEFAULT_MAX_ITEMS+5; i++)
    {
        ss4.insert(i);        // Insert 200 items in s
    }
    
    assert(ss4.size() == 200);
    
    
//    To test the case of inserting an empty string, change the ItemType to string and comment out the upper tests and use the following codes to test.
//    
//    
//    Set ss;
//    ss.insert("dosa");
//    assert(!ss.contains(""));
//    ss.insert("tortilla");
//    ss.insert("");
//    ss.insert("focaccia");
//    assert(ss.contains(""));
//    ss.erase("dosa");
//    assert(ss.size() == 3  &&  ss.contains("focaccia")  &&  ss.contains("tortilla")  &&
//           ss.contains(""));
//    string v;
//    assert(ss.get(1, v)  &&  v == "focaccia");
//    assert(ss.get(0, v)  &&  v == "");
}

int main()
{
    test();
    cout << "Passed all tests" << endl;
}

