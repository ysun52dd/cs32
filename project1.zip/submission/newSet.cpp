//
//  newSet.cpp
//  hw1
//
//  Created by SunYutong on 4/16/17.
//  Copyright © 2017 SunYutong. All rights reserved.
//

#include "newSet.h"
#include <iostream>
#include <cstdlib>




Set::Set(int capacity)
:m_size(0),m_capacity(capacity)
{
    if (capacity < 0)
    {
        std::cout << "A Set capacity must not be negative." << std::endl;
        std::exit(1);
    }
    m_data = new ItemType[m_capacity];

}


bool Set::insert(const ItemType& value)
{
    
    if (contains(value)||size()>=m_capacity)
        return false;
    if(size()==0)
    {
        m_data[0]=value;
        
        
    }
    else{
        
        for(int i=0; i<size();i++)
        {
            if(value<m_data[i])
            {
                for(int k=size();k>i;k--)
                    m_data[k]=m_data[k-1];
                m_data[i]=value;
                break;
            }
            else{
                m_data[size()]=value;
            }
        }
    }
    m_size++;
    return true;
    
}



bool Set::erase(const ItemType& value)
{
    
    if (!contains(value))
        return false;
    
    
    for (int i = 0; i < size(); i++)
    {
        if (m_data[i] == value)
        {
            for(int k=i; k<size()-1; k++)
                m_data[k] = m_data[k+1];
            m_size--;
        }
    }
    return true;
}

bool Set::contains(const ItemType& value) const
{
    for (int i = 0; i < size(); i++)
    {
        if (m_data[i] == value)
            return true;
    }
    
    return false;
    
}


bool Set::get(int i, ItemType& value) const
{
    if (i < 0  ||  i >= size())
        return false;
    value = m_data[i];
    return true;
}



void Set::swap(Set& other)
{
    //Swap pointer
    ItemType* tempData = m_data;
    m_data = other.m_data;
    other.m_data = tempData;


    // Swap sizes
    int tempSize = m_size;
    m_size = other.m_size;
    other.m_size = tempSize;
    
    //Swap capacity
    int tempCapacity = m_capacity;
    m_capacity = other.m_capacity;
    other.m_capacity=tempCapacity;
}



Set::~Set()
{
    delete [] m_data;
}

Set::Set(const Set& other)
: m_size(other.m_size), m_capacity(other.m_capacity)
{
    m_data = new ItemType[m_capacity];
    
    // Since the only elements that matter are those up to m_size, only
    // they have to be copied.
    
    for (int k = 0; k < m_size; k++)
        m_data[k] = other.m_data[k];
}


Set& Set::operator=(const Set& rhs)
{
    if (this != &rhs)
    {
        Set temp(rhs);
        swap(temp);
    }
    return *this;
}



