//
//  newSet.h
//  hw1
//
//  Created by SunYutong on 4/12/17.
//  Copyright © 2017 SunYutong. All rights reserved.
//
//
#ifndef newSet_h
#define newSet_h

#include <string>
using namespace std;

typedef unsigned long ItemType;

const int DEFAULT_MAX_ITEMS = 200;

class Set
{
public:
             
    Set(int capacity=DEFAULT_MAX_ITEMS);
    bool empty() const;  // Return true if the sequence is empty, otherwise false.
    int size() const;    // Return the number of items in the sequence.
    
    bool insert(const ItemType& value);
    //Insert value into the set if it is not already present.  Return
    // true if the value was actually inserted.  Leave the set unchanged
    // and return false if the value was not inserted (perhaps because it
    // is already in the set or because the set has a fixed capacity and
    // is full).
    
    bool erase(const ItemType& value);
    // Remove the value from the set if present.  Return true if the
    // value was removed; otherwise, leave the set unchanged and
    // return false.
    
    bool contains(const ItemType& value) const;
    // Return true if the value is in the set, otherwise false.
    
    bool get(int i, ItemType& value) const;
    // If 0 <= i < size(), copy into value the item in the set that is
    // greater than exactly i items in the set and return true.  Otherwise,
    // leave value unchanged and return false.
    
    
    void swap(Set& other);
    // Exchange the contents of this sequence with the other one.
//    void dump() const;
    ~Set();
    Set(const Set& other);
    Set& operator=(const Set& rhs);

private:
    ItemType* m_data;  // the items in the sequence
    int      m_size;// number of items in the sequence
    int      m_capacity;
    
    // At any time, the elements of m_data indexed from 0 to m_size-1
    // are in use.
    
};

// Inline implementations

inline
int Set::size() const
{
    return m_size;
}

inline
bool Set::empty() const
{
    return size() == 0;
}


#endif /* newSet_h */
