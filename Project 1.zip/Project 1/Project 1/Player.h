//
//  Player.h
//  Project 1
//
//  Created by SunYutong on 4/7/17.
//  Copyright © 2017 SunYutong. All rights reserved.
//

#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;


#ifndef Player_h
#define Player_h

#include "globals.h"

class Arena;

class Player
{
public:
    // Constructor
    Player(Arena* ap, int r, int c);
    
    // Accessors
    int  row() const;
    int  col() const;
    bool isDead() const;
    
    // Mutators
    string dropPoisonPellet();
    string move(int dir);
    void   setDead();
    
private:
    Arena* m_arena;
    int    m_row;
    int    m_col;
    bool   m_dead;
};


#endif /* Player_h */
