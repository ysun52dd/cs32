//
//  utilities.cpp
//  Project 1
//
//  Created by SunYutong on 4/7/17.
//  Copyright © 2017 SunYutong. All rights reserved.
//

#include "utilities.hpp"
