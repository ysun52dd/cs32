//
//  utilities.hpp
//  Project 1
//
//  Created by SunYutong on 4/7/17.
//  Copyright © 2017 SunYutong. All rights reserved.
//

#ifndef utilities_hpp
#define utilities_hpp

#include <stdio.h>

#endif /* utilities_hpp */
