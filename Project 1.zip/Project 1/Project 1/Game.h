//
//  Game.h
//  Project 1
//
//  Created by SunYutong on 4/7/17.
//  Copyright © 2017 SunYutong. All rights reserved.
//

#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;

#ifndef Game_h
#define Game_h

#include "globals.h"
class Arena;

class Game
{
public:
    // Constructor/destructor
    Game(int rows, int cols, int nRats);
    ~Game();
    
    // Mutators
    void play();
    
private:
    Arena* m_arena;
    
    // Helper functions
    string takePlayerTurn();
};


#endif /* Game_h */
