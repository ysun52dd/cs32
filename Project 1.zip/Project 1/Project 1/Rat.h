//
//  Rat.h
//  Project 1
//
//  Created by SunYutong on 4/7/17.
//  Copyright © 2017 SunYutong. All rights reserved.
//

#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;

#ifndef Rat_h
#define Rat_h

#include "globals.h"

class Arena;

class Rat
{
public:
    // Constructor
    Rat(Arena* ap, int r, int c);
    
    // Accessors
    int  row() const;
    int  col() const;
    bool isDead() const;
    
    // Mutators
    void move();
    
private:
    Arena* m_arena;
    int    m_row;
    int    m_col;
    int    m_health;
    int    m_idleTurnsRemaining;
};


#endif /* Rat_h */
