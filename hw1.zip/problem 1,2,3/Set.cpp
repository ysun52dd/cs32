//
//  Set.cpp
//  hw1
//
//  Created by SunYutong on 4/12/17.
//  Copyright © 2017 SunYutong. All rights reserved.
//

#include "Set.h"

Set::Set()
: m_size(0)
{
}



bool Set::insert(const ItemType& value)
{
    
    if (contains(value)||size()==DEFAULT_MAX_ITEMS)
        return false;
    if(size()==0)
    {
        m_data[0]=value;
        
       
    }
    else{
    
    for(int i=0; i<size();i++)
    {
        if(value<m_data[i])
        {
            for(int k=size();k>i;k--)
                m_data[k]=m_data[k-1];
            m_data[i]=value;
            break;
        }
        else{
            m_data[size()]=value;
        }
    }
    }
    m_size++;
        return true;
    
}


bool Set::erase(const ItemType& value)
{
    
    if (!contains(value))
        return false;
   
    
    for (int i = 0; i < size(); i++)
    {
        if (m_data[i] == value)
        {
          m_data[i] = m_data[i+1];
          m_size--;
        }
    }
    return true;
}

bool Set::contains(const ItemType& value) const
{
    for (int i = 0; i < size(); i++)
    {
        if (m_data[i] == value)
            return true;
    }
    
            return false;

}


bool Set::get(int i, ItemType& value) const
{
    if (i < 0  ||  i >= size())
        return false;
    value = m_data[i];
    return true;
}



void Set::swap(Set& other)
{
    // Exchange the contents of this sequence with the other one.
    
    int maxSize;
    if (m_size > other.m_size )
        maxSize=m_size;
    else
        maxSize=other.m_size;
    
    for (int k = 0; k < maxSize; k++)
    {
        ItemType tempItem = m_data[k];
        m_data[k] = other.m_data[k];
        other.m_data[k] = tempItem;
    }
    
    // Swap sizes
    
    int tempSize = m_size;
    m_size = other.m_size;
    other.m_size = tempSize;
}

