//
//  testSSNSet.cpp
//  hw1
//
//  Created by SunYutong on 4/16/17.
//  Copyright © 2017 SunYutong. All rights reserved.
//


#include "Set.h"
#include "SSNSet.h"
#include <iostream>
#include <string>
#include <cassert>
using namespace std;


int main()
{
    SSNSet s;
    
    ItemType x = 9876543;
    s.add(123456789);
    
    assert(s.size()==1);
    s.add(x);
    assert(s.size()==2);
    
    s.add(876543210);
    assert(s.size()==3);
    
    s.add(8143847113);
    
    s.print();
    
    SSNSet s2;
    s2.add(3103079626);
    s2.print();
    
    cout << "Passed all tests" << endl;
}
