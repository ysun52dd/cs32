//
//  SSNSet.cpp
//  hw1
//
//  Created by SunYutong on 4/16/17.
//  Copyright © 2017 SunYutong. All rights reserved.
//

#include <iostream>

#include "SSNSet.h"
#include "Set.h"

SSNSet::SSNSet()
{}

bool SSNSet::add(unsigned long ssn)
{
    
    return m_ssn.insert(ssn);
}

void SSNSet::print() const
{
    for(int i=0; i<size(); i++)
    {
        unsigned long printSsn;
        m_ssn.get(i, printSsn);
        std::cout<<printSsn<<endl;
        
    }
        
}
