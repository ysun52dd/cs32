//
//  mazestack.cpp
//  hw2
//
//  Created by SunYutong on 4/27/17.
//  Copyright © 2017 SunYutong. All rights reserved.
//

#include <stack>
#include <string>
#include <iostream>


using namespace std;

//const char WALL = 'X';
const char OPEN = '.';
const char SEEN = 'o';

class Coord
{
public:
    Coord(int rr, int cc) : m_r(rr), m_c(cc) {}
    int r() const { return m_r; }
    int c() const { return m_c; }
private:
    int m_r;
    int m_c;
};

void explore(char maze[][10], stack<Coord>& toDo, int r, int c)
{
    if (maze[r][c] == OPEN)
    {
        toDo.push(Coord(r,c));
        maze[r][c] = SEEN;  // anything non-OPEN will do
    }
}

bool pathExists(char maze[][10], int sr, int sc, int er, int ec)
// Return true if there is a path from (sr,sc) to (er,ec)
// through the maze; return false otherwise
{
    if (sr < 0  ||  sr > 9  ||  sc < 0  || sc > 9  ||
        er < 0  ||  er > 9  ||  ec < 0  || ec > 9  ||
        maze[sr][sc] != OPEN  ||  maze[er][ec] != OPEN)
        return false;

    stack<Coord> toDo;
    explore(maze, toDo, sr, sc);
    
    while ( ! toDo.empty() )
    {
        Coord curr = toDo.top();
        toDo.pop();
        
        const int cr = curr.r();
        const int cc = curr.c();
        
        if (cr == er  &&  cc == ec)
            return true;
        
        explore(maze, toDo, cr-1, cc);  // north
        explore(maze, toDo, cr, cc+1);  // east
        explore(maze, toDo, cr+1, cc);  // south
        explore(maze, toDo, cr, cc-1);  // west
    }
    return false;
}


//int main()
//{
//    char maze[10][10] = {
//            { 'X','X','X','X','X','X','X','X','X','X'},
//            { 'X','.','.','.','.','.','.','.','.','X'},
//            { 'X','X','.','X','.','X','X','X','X','X'},
//            { 'X','.','.','X','.','X','.','.','.','X'},
//            { 'X','.','.','X','.','.','.','X','.','X'},
//            { 'X','X','X','X','.','X','X','X','.','X'},
//            { 'X','.','X','.','.','.','.','X','X','X'},
//            { 'X','.','X','X','X','.','X','X','.','X'},
//            { 'X','.','.','.','X','.','.','.','.','X'},
//            { 'X','X','X','X','X','X','X','X','X','X'}
//
//    };
//    
//    if (pathExists(maze,6,4, 1,1))
//        cout << "Solvable!" << endl;
//    else
//        cout << "Out of luck!" << endl;
//}
//
