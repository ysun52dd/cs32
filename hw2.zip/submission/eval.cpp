//
//  eval.cpp
//  hw2
//
//  Created by SunYutong on 4/27/17.
//  Copyright © 2017 SunYutong. All rights reserved.
//

#include <iostream>
#include <string>
#include <stack>
#include <cctype>
#include <cassert>
using namespace std;

bool isAlphaOrCloseParen(char ch);


int precedence(char ch);
//  Precondition:  ch is in "|&!("

const int RET_OK_EVALUATION      = 0;
const int RET_INVALID_EXPRESSION = 1;




int evaluate(string infix, string& postfix, bool& result)
{
// First convert infix to postfix

//    For each character ch in the infix string
//    Switch (ch)
//case operand:
//    append ch to end of postfix
//    break
//case '(':
//    push ch onto the operator stack
//    break
//case ')':
//    // pop stack until matching '('
//    While stack top is not '('
//    append the stack top to postfix
//    pop the stack
//    pop the stack  // remove the '('
//    break
//case operator:
//    While the stack is not empty and the stack top is not '('
//    and precedence of ch <= precedence of stack top
//    append the stack top to postfix
//    pop the stack
//    push ch onto the stack
//    break
//    While the stack is not empty
//    append the stack top to postfix
//    pop the stack

    postfix = "";//    Initialize postfix to empty
    stack<char> operatorStack;//    Initialize the operator stack to empty
    char prevch = '|';  // pretend the previous character was an operator
    
    for (size_t k = 0; k < infix.size(); k++)
    {
        char ch = infix[k];
        switch(ch)
        {
            case ' ':
                continue;  // do not set prevch to this char and move to the next character
                
            case '(':
            //case '!':
                if (isAlphaOrCloseParen(prevch)) //previous term of '(' must not be T/F or ')'
                    return RET_INVALID_EXPRESSION;
                operatorStack.push(ch); //push '(' to stack
                
                break;
                
            case ')':
                if ( ! isAlphaOrCloseParen(prevch)) //previous term of ')' must be T/F or another ')'
                    return RET_INVALID_EXPRESSION;
                for (;;)
                {
                    if (operatorStack.empty())
                        return RET_INVALID_EXPRESSION;  // too many ')'
                    char c = operatorStack.top();
                    operatorStack.pop();
                    if (c == '(') //pop all the operators until '('
                        break;
                    postfix += c; //append it to the postfix
                }
                break;
            
            //operators:
            case '!':
                if (isAlphaOrCloseParen(prevch)) //previous term of '!' must not be T/F or ')'
                    return RET_INVALID_EXPRESSION;
                while ( ! operatorStack.empty()  &&
                       precedence(ch) <= precedence(operatorStack.top()) ) //pop the '!' operator from the stack if the top of the stack is '!'
                {
                    postfix += operatorStack.top();
                    operatorStack.pop();
                }

                operatorStack.push(ch); //push '!' to stack
                break;


            case '|':
            case '&':
                if ( ! isAlphaOrCloseParen(prevch)) //if the previous term is not T/F or ')'
                    return RET_INVALID_EXPRESSION;
                while ( ! operatorStack.empty()  &&
                       precedence(ch) <= precedence(operatorStack.top()) ) //pop the operator from the stack to the postfix if it has greater of equal precedence compared to the current operator
                {
                    postfix += operatorStack.top();
                    operatorStack.pop();
                }
                operatorStack.push(ch); //push the current operator
                break;
                
            default:  // had better be a alphabet
                if (ch!='T'&&ch!='F')
                    return RET_INVALID_EXPRESSION;
                if (isAlphaOrCloseParen(prevch)) //previous term of 'T'/'F' should not be ')' or 'T'/'F'
                    return RET_INVALID_EXPRESSION;
                postfix += ch;
                break;
        }
        prevch = ch;
    }
    
    // end of expression; pop remaining operators
    
    if ( ! isAlphaOrCloseParen(prevch)) //invalid if the last character is not 'T'/'F' or ')'
        return RET_INVALID_EXPRESSION;
    while ( ! operatorStack.empty())
    {
        char c = operatorStack.top();
        operatorStack.pop();
        if (c == '(')
            return RET_INVALID_EXPRESSION;  // too many '('
        postfix += c;
    }
    if (postfix.empty())
        return RET_INVALID_EXPRESSION;  // empty expression
    
    
    
// postfix now contains the converted expression
// Now evaluate the postfix expression

//    Initialize the operand stack to empty
//    For each character ch in the postfix string
//    if ch is an operand
//        push the value that ch represents onto the operand stack
//        else // ch is a binary operator
//            set operand2 to the top of the operand stack
//            pop the stack
//            set operand1 to the top of the operand stack
//            pop the stack
//            apply the operation that ch represents to operand1 and
//            operand2, and push the result onto the stack
//            When the loop is finished, the operand stack will contain one item,
//            the result of evaluating the expression
    stack<bool> operandStack;
    for (size_t k = 0; k < postfix.size(); k++)
    {
        char ch = postfix[k];
        if (isalpha(ch))
        {
            if(ch=='T')
            operandStack.push(true);
            else
                operandStack.push(false);
        }
        else
        {
            bool opd2 = operandStack.top();
            operandStack.pop();
            if (ch == '!')
                operandStack.push(!opd2);
            else
            {   bool opd1 = operandStack.top();
                operandStack.pop();
                if (ch == '&')
                    operandStack.push(opd1 && opd2);
                else if (ch == '|')
                    operandStack.push(opd1 || opd2);
                else  // Impossible!
                    return RET_INVALID_EXPRESSION;  // pretend it's an invalid expression
            }
        }
    }
    if (operandStack.size() != 1)  // Invalid if the size of result in stack is not 1
        return RET_INVALID_EXPRESSION;  // pretend it's an invalid expression
    result = operandStack.top();
    
    return RET_OK_EVALUATION;
}


bool isAlphaOrCloseParen(char ch)
{
    
    if(ch!='T'&&ch!='F'&&ch!=')')
        return false;
    return true;
    
}

int precedence(char ch)
//  Precondition:  ch is in "|&!("
{
    static const string ops = "|&!(";
    static const int prec[4] = { 1, 2, 3, 0 };
    size_t pos = ops.find(ch);
    assert(pos != string::npos);  // must be found!
    return prec[pos];
}


//int main()
//{
//    string pf;
//    bool answer;
//    assert(evaluate("!", pf, answer)==1);
//    assert(evaluate("!(!T&F|F)", pf, answer)==0 && answer);
//    assert(evaluate("T&!(F|T&T|F)|!!!(F&T&F)", pf, answer)==0 && pf=="TFTT&|F|!&!!FT&F&!|" && answer);
//    assert(evaluate("!(F|T)", pf, answer)==0 && pf =="FT|!" && !answer);
//
//    assert(evaluate("T| F", pf, answer) == 0 &&  pf == "TF|"   && answer);
//    assert(evaluate("T|", pf, answer) == 1);
//    assert(evaluate("F F", pf, answer) == 1);
//    assert(evaluate("TF", pf, answer) == 1);
//    assert(evaluate("()", pf, answer) == 1);
//    assert(evaluate("|T", pf, answer) == 1);
//    assert(evaluate("fT", pf, answer) == 1);
//    assert(evaluate("abc", pf, answer) == 1);
//    assert(evaluate("123", pf, answer) == 1);
//    assert(evaluate("|!!!", pf, answer) == 1);
//    assert(evaluate("T(F|T)", pf, answer) == 1);
//    assert(evaluate("T(&T)", pf, answer) == 1);
//    assert(evaluate("(T&(F|F)", pf, answer) == 1);
//    assert(evaluate("", pf, answer) == 1);
// 
//    assert(evaluate("F  |  !F & (T&F) ", pf, answer) == 0
//           &&  pf == "FF!TF&&|"  &&  !answer);
//    assert(evaluate(" F  ", pf, answer) == 0 &&  pf == "F"  &&  !answer);
//    assert(evaluate("((T))", pf, answer) == 0 &&  pf == "T"  &&  answer);
//       cout << "Passed all tests" << endl;
//}
