//
//  testPlayer.cpp
//  project3
//
//  Created by SunYutong on 5/19/17.
//  Copyright © 2017 SunYutong. All rights reserved.
//

#include <stdio.h>
#include "Player.h"

class Ship;
class Game;
class Board;

#include "Board.h"
#include <list>
#include <vector>
#include "Game.h"
#include "globals.h"
#include <iostream>
#include <string>
#include <cassert>

bool addStandardShips(Game& g)
{
    return g.addShip(4, 'A', "aircraft carrier" )&&  g.addShip(3, 'B', "battleship")&& g.addShip(3, 'D', "destroyer") &&  g.addShip(2, 'S', "submarine");
    //&&   g.addShip(2, 'P', "patrol boat");
}


int main()
{
    
    Game g(6,6);
//    assert(g.rows()==10 && g.cols()==10);
//    Point p1(11,11),p2(0,2), p3(-1,7),p4(-5,-4);
//    Point p5=g.randomPoint();
//    
//    assert(g.isValid(p1)==false && g.isValid(p2)==true && g.isValid(p3)==false && g.isValid(p4)==false && g.isValid(p5)==true);
//    
//    g.addShip(5, 'A', "aircraft");
//    g.addShip(4, 'B', "battleship");
//    g.addShip(3, 'D', "destroyer");
//    g.addShip(3, 'S', "submarine");
//    g.addShip(2, 'P', "patrol");
//    
//    assert(g.nShips()==5);
//    
//    assert(g.shipName(0)=="aircraft");
//    assert(g.shipName(1)=="battleship");
//    assert(g.shipName(2)=="destroyer");
//    assert(g.shipName(3)=="submarine");
//    assert(g.shipName(4)=="patrol");
//    
//    assert(g.shipLength(0)==5);
//    assert(g.shipLength(1)==4);
//    assert(g.shipLength(2)==3);
//    assert(g.shipLength(3)==3);
//    assert(g.shipLength(4)==2);
//    
//    assert(g.shipSymbol(0)=='A');
//    assert(g.shipSymbol(1)=='B');
//    assert(g.shipSymbol(2)=='D');
//    assert(g.shipSymbol(3)=='S');
//    assert(g.shipSymbol(4)=='P');
//    
//    Board b1(g), b2(g);
//    b1.clear();
//    //test cases for display function:
//    b1.display(false);//a clear board before adding ships
//    cout<<endl<<'1'<<endl;
//    b1.display(true);//the same board as last one
//    cout<<endl<<'2'<<endl;
//    b2.block();
//    b2.display(false);//a blocked board before adding ships
//    cout<<endl<<'3'<<endl;
//    b2.unblock();
//    b2.display(false);
//    cout<<endl<<'4'<<endl;
//    //Point p1(11,11),p2(0,2), p3(-1,7),p4(-5,-4);Point p5=g.randomPoint();
//    Point p6(0,0), p7(6,6), p8(3,4), p9(9,8), p10(2,8), p11(7,1), p12(0,3),p13(3,0),p14(3,6),p15(3,5);
//    
//    //test cases for placeShip function:
//    assert(b2.placeShip(p6, 0, HORIZONTAL)==true);
//    b2.display(false);
//    cout<<endl<<'5'<<endl;
//    
//    assert(b2.placeShip(p12, 1, VERTICAL)==false);
//    assert(b2.placeShip(p7, 1, VERTICAL)==true);
//    assert(b2.placeShip(p8, 2, HORIZONTAL)==true);
//    assert(b2.placeShip(p9, 3, VERTICAL)==false);
//    assert(b2.placeShip(p10, 3, VERTICAL)==true);
//    assert(b2.placeShip(p11, 4, HORIZONTAL)==true);
//    
//    //unplaceShip function:
//    assert(b2.unplaceShip(p11, 4, HORIZONTAL)==true);
//    assert(b2.unplaceShip(p9, 4, HORIZONTAL)==false);
//    assert(b2.unplaceShip(p12, 2, VERTICAL)==false);
//    
//    assert(b2.placeShip(p11, 4, HORIZONTAL)==true);
//    b2.display(false);
//    cout<<endl<<'6'<<endl;
//    
//    //attack function:
//    bool shothit, shipdestroyed;
//    int shipid;
//    assert(b2.attack(p6, shothit, shipdestroyed, shipid)==true && shothit==true && shipdestroyed==false);
//    b2.display(true);
//    cout<<endl<<'7'<<endl;
//    b2.display(false);
//    cout<<endl<<'8'<<endl;
//    assert(b2.attack(p1, shothit, shipdestroyed, shipid)==false && shothit==false && shipdestroyed==false);
//    
//    assert(b2.attack(p13, shothit, shipdestroyed, shipid)==true && shothit==false && shipdestroyed==false);
//    assert(b2.attack(p14, shothit, shipdestroyed, shipid)==true && shothit==true && shipdestroyed==false);
//    b2.display(true);
//    cout<<endl<<'9'<<endl;
//    b2.display(false);
//    cout<<endl<<"10"<<endl;
//    assert(b2.attack(p15, shothit, shipdestroyed, shipid)==true && shothit==true && shipdestroyed==false);
//    b2.display(true);
//    cout<<endl<<"11"<<endl;
//    b2.display(false);
//    cout<<endl<<"12"<<endl;
//    assert(b2.attack(p8, shothit, shipdestroyed, shipid)==true && shothit==true && shipdestroyed==true && shipid==2);
//    //D destroyed
//    b2.display(true);
//    cout<<endl<<"13"<<endl;
//    b2.display(false);
//    cout<<endl<<"14"<<endl;
//    
//    //allDestroyed function:
//    Point p16(0,1), p17(0,2), p18(0,3), p19(0,4), p20(3,8), p21(4,8), p22(7,6), p23(8,6), p24(9,6),p25(7,2);
//    //p10(2,8), p7(6,6), p11(7,1)
//    assert(b2.attack(p16, shothit, shipdestroyed, shipid)==true && shothit==true && shipdestroyed==false );
//    assert(b2.attack(p17, shothit, shipdestroyed, shipid)==true && shothit==true && shipdestroyed==false );
//    assert(b2.attack(p18, shothit, shipdestroyed, shipid)==true && shothit==true && shipdestroyed==false );
//    assert(b2.attack(p19, shothit, shipdestroyed, shipid)==true && shothit==true && shipdestroyed==true && shipid==0);
//    //A destroyed
//    assert(b2.attack(p10, shothit, shipdestroyed, shipid)==true && shothit==true && shipdestroyed==false );
//    assert(b2.attack(p20, shothit, shipdestroyed, shipid)==true && shothit==true && shipdestroyed==false );
//    assert(b2.attack(p21, shothit, shipdestroyed, shipid)==true && shothit==true && shipdestroyed==true && shipid== 3);
//    assert(b2.allShipsDestroyed()==false);
//    //S destroyed
//    assert(b2.attack(p7, shothit, shipdestroyed, shipid)==true && shothit==true && shipdestroyed==false );
//    assert(b2.attack(p22, shothit, shipdestroyed, shipid)==true && shothit==true && shipdestroyed==false );
//    assert(b2.attack(p23, shothit, shipdestroyed, shipid)==true && shothit==true && shipdestroyed==false);
//    assert(b2.attack(p24, shothit, shipdestroyed, shipid)==true && shothit==true && shipdestroyed==true && shipid== 1);
//    assert(b2.allShipsDestroyed()==false);
//    //B destroyed
//    assert(b2.attack(p11, shothit, shipdestroyed, shipid)==true && shothit==true && shipdestroyed==false );
//    assert(b2.attack(p25, shothit, shipdestroyed, shipid)==true && shothit==true && shipdestroyed==true && shipid== 4);
//    assert(b2.allShipsDestroyed()==true);
//    b2.display(true);
//    cout<<endl<<"15"<<endl;
//    b2.display(false);
//    cout<<endl<<"16"<<endl;
    
    addStandardShips(g);
    Player* pl2 = createPlayer("good", "Heidi the Good", g);
    Player* pl1 = createPlayer("awful", "Shuman the Awful", g);
    g.play(pl1, pl2);
    delete pl1;
    delete pl2;
    
    cout<<"passed";
}
