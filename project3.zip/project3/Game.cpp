//
//  Game.cpp
//  project3
//
//  Created by SunYutong on 5/17/17.
//  Copyright © 2017 SunYutong. All rights reserved.
//
#include "Game.h"
#include "Board.h"
#include "Player.h"
#include "globals.h"
#include <iostream>
#include <string>
#include <cstdlib>
#include <cctype>
#include <cassert>
using namespace std;
class GameImpl
{
public:
    GameImpl(int nRows, int nCols);
    int rows() const;
    int cols() const;
    bool isValid(Point p) const;
    Point randomPoint() const;
    bool addShip(int length, char symbol, string name);
    int nShips() const;
    int shipLength(int shipId) const;
    char shipSymbol(int shipId) const;
    string shipName(int shipId) const;
    Player* play(Player* p1, Player* p2, Board& b1, Board& b2, bool shouldPause);
private:
    int m_row;
    int m_col;
    class Ship
    {
    public:
        int m_length;
        char m_symbol;
        string m_name;
        int id;
        
        Ship(int length, char symbol, string name)
        :m_length(length),m_symbol(symbol),m_name(name)
        { }
        
    };
    vector<Ship> m_ship;

};

void waitForEnter()
{
    cout << "Press enter to continue: ";
    cin.ignore(10000, '\n');
}

GameImpl::GameImpl(int nRows, int nCols)
{
    m_row=nRows;
    m_col=nCols;
    // This compiles but may not be correct
}

int GameImpl::rows() const
{
    
    return m_row;  // number of rows on the board
}

int GameImpl::cols() const
{
    return m_col;  // number of columns on the board
}

bool GameImpl::isValid(Point p) const
{
    return p.r >= 0  &&  p.r < rows()  &&  p.c >= 0  &&  p.c < cols();
}

Point GameImpl::randomPoint() const
{
    return Point(randInt(rows()), randInt(cols()));
}

bool GameImpl::addShip(int length, char symbol, string name)
{
    
    Ship s(length,symbol, name);
    s.id=(int)m_ship.size();//record the shipid which is equal to the index of that ship int the vector m_ship
    m_ship.push_back(s);
    return true;

      // This compiles but may not be correct
}

int GameImpl::nShips() const
{
    return (int)m_ship.size();  // This compiles but may not be correct
}

int GameImpl::shipLength(int shipId) const
{
    return m_ship[shipId].m_length;  // This compiles but may not be correct
}

char GameImpl::shipSymbol(int shipId) const
{
    return m_ship[shipId].m_symbol;  // This compiles but may not be correct
}

string GameImpl::shipName(int shipId) const
{
    return m_ship[shipId].m_name;  // This compiles but may not be correct
}

Player* GameImpl::play(Player* p1, Player* p2, Board& b1, Board& b2, bool shouldPause)
{
    /* This function runs a complete game between the two indicated players, returning a
 pointer to the player who won the game, or nullptr if some situation occurred that makes
 it impossible to complete the game (e.g., a player being unable to place the ships on their
 board). The parameter p1 is a pointer to the player who goes first; p2 is a pointer to the
 other player.
  The play function must do the following:
 1. It creates two Board objects, one for each of the players.
 */

    //If the third parameter is true, then after displaying the result of each shot, the function displays a "Press enter to continue: " prompt and waits for the user to press enter before continuing. This parameter defaults to true if the play function is called with only two arguments. If the parameter is false, no such pause occurs; this is useful when testing the function merely to determine the winner, such as might be done from a script that discards the actual output.

    

    //2. It calls the placeShips function of each player to place the ships on their respective board. It is possible that the placeShips function may fail to place the ships in some instances (e.g., if the game parameters are such that there is no configuration of ships that will fit, or if a MediocrePlayer is unable to place all of the ships because of blocked squares). If a player's placeShips function returns false, your play function must return nullptr.
    if(p1->placeShips(b1)==false || p2->placeShips(b2)==false)
        return nullptr;
    //3. Once both players have successfully placed their ships, game play starts.
 

    //4. Until one of the players wins the game:
    while(!b1.allShipsDestroyed() && !b2.allShipsDestroyed())
    {
        //pause
        if(shouldPause)
    {
        
        cout<<"Press enter to continue:";
        bool enter=false;
        while (!enter)
        {
            if(cin.get()=='\n')
            {
                enter=true;
                //cout<<"passed"<<endl;
            }
        }
    }
        bool shothit1,shothit2, shipdestroyed1, shipdestroyed2;
        bool goodattack1,goodattack2;
        int shipid1, shipid2;
        //a. Display the second player's board (since the first player will be attacking
        // that board). If the first player is human, do not show undamaged segments
        // on the opponent's board, since that would be cheating. If the first player is
        // not human, then show the entire opponent's board, since we're just an
        // onlooker to what the computer player will decide for itself.
        
        //p1:
        cout<<p1->name()<<"'s turn.  Board for "<<p2->name()<<':'<<endl;
        b2.display(p1->isHuman());
        //b. Make the first player's attack.
        if(p1->isHuman())
        cout<<"Enter the row and column to attack (e.g, 3 5): ";
        Point attackp1=p1->recommendAttack();
        goodattack1=b2.attack(attackp1, shothit1, shipdestroyed1, shipid1);
        
        //record the attack result
        p1->recordAttackResult(attackp1, goodattack1, shothit1, shipdestroyed1, shipid1);
        
        //print the missed shot
        if(!goodattack1)
            cout<<p1->name()<<" wasted a shot at ("<<attackp1.r<<','<<attackp1.c<<")."<<endl;
        else
        {
        //c. Display the result of the attack.
        if(!shothit1)
            cout<<p1->name()<<" attacked ("<<attackp1.r<<','<<attackp1.c<<") and missed, resulting in:"<<endl;
        if(shothit1)
            cout<<p1->name()<<" attacked ("<<attackp1.r<<','<<attackp1.c<<") and hit something, resulting in:"<<endl;
        b2.display(p1->isHuman());
        }
        
        //check if there is a winner
        if(b1.allShipsDestroyed())//p2 wins the game
        {
            cout<<p2->name()<<" wins!"<<endl;
            if( p1->isHuman())
                b2.display(false);
            return p2;
        }
        if(b2.allShipsDestroyed() )//p1 wins the game
        {
            cout<<p1->name()<<" wins!"<<endl;
            if(p2->isHuman())
                b1.display(false);
            return p1;
        }
        
        //pause
        if(shouldPause)
        {
            
            cout<<"Press enter to continue:";
            bool enter=false;
            while (!enter)
            {
                if(cin.get()=='\n')
                {
                    enter=true;
                    //cout<<"passed"<<endl;
                }
            }
        }

        //p2:
        cout<<p2->name()<<"'s turn.  Board for "<<p1->name()<<':'<<endl;
        //d. Repeat these steps with the roles of the first and second player reversed.
        b1.display(p2->isHuman());
        if(p2->isHuman())
        cout<<"Enter the row and column to attack (e.g, 3 5): ";
        Point attackp2=p2->recommendAttack();
        goodattack2=b1.attack(attackp2,shothit2, shipdestroyed2, shipid2);
        
        //record the attack result
        p2->recordAttackResult(attackp2, goodattack2, shothit2, shipdestroyed2, shipid2);

        //print the missed shot
        if(!goodattack2)
            cout<<p2->name()<<" wasted a shot at ("<<attackp2.r<<','<<attackp2.c<<")."<<endl;
        else
        {
        if(!shothit2)
            cout<<p2->name()<<" attacked ("<<attackp2.r<<','<<attackp2.c<<") and missed, resulting in:"<<endl;
        if(shothit2)
            cout<<p2->name()<<" attacked ("<<attackp2.r<<','<<attackp2.c<<") and hit something, resulting in:"<<endl;
        b1.display(p2->isHuman());
        }
    
    }
//5. If the losing player is human, display the winner's board, showing everything. You can't go wrong by having your play function conduct the game the way it does in our sample program.
    if(b1.allShipsDestroyed())//p2 wins the game
    {
        cout<<p2->name()<<" wins!"<<endl;
        if( p1->isHuman())
            b2.display(false);
        return p2;
    }
    if(b2.allShipsDestroyed() )//p1 wins the game
    {
        cout<<p1->name()<<" wins!"<<endl;
        if(p2->isHuman())
            b1.display(false);
        return p1;
    }
    
    return nullptr;  // This compiles but may not be correct
}


//******************** Game functions *******************************

// These functions for the most part simply delegate to GameImpl's functions.
// You probably don't want to change any of the code from this point down.

Game::Game(int nRows, int nCols)
{
    if (nRows < 1  ||  nRows > MAXROWS)
    {
        cout << "Number of rows must be >= 1 and <= " << MAXROWS << endl;
        exit(1);
    }
    if (nCols < 1  ||  nCols > MAXCOLS)
    {
        cout << "Number of columns must be >= 1 and <= " << MAXCOLS << endl;
        exit(1);
    }
    m_impl = new GameImpl(nRows, nCols);
}

Game::~Game()
{
    delete m_impl;
}

int Game::rows() const
{
    return m_impl->rows();
}

int Game::cols() const
{
    return m_impl->cols();
}

bool Game::isValid(Point p) const
{
    return m_impl->isValid(p);
}

Point Game::randomPoint() const
{
    return m_impl->randomPoint();
}

bool Game::addShip(int length, char symbol, string name)
{
    if (length < 1)
    {
        cout << "Bad ship length " << length << "; it must be >= 1" << endl;
        return false;
    }
    if (length > rows()  &&  length > cols())
    {
        cout << "Bad ship length " << length << "; it won't fit on the board"
        << endl;
        return false;
    }
    if (!isascii(symbol)  ||  !isprint(symbol))
    {
        cout << "Unprintable character with decimal value " << symbol
        << " must not be used as a ship symbol" << endl;
        return false;
    }
    if (symbol == 'X'  ||  symbol == '.'  ||  symbol == 'o')
    {
        cout << "Character " << symbol << " must not be used as a ship symbol"
        << endl;
        return false;
    }
    int totalOfLengths = 0;
    for (int s = 0; s < nShips(); s++)
    {
        totalOfLengths += shipLength(s);
        if (shipSymbol(s) == symbol)
        {
            cout << "Ship symbol " << symbol
            << " must not be used for more than one ship" << endl;
            return false;
        }
    }
    if (totalOfLengths + length > rows() * cols())
    {
        cout << "Board is too small to fit all ships" << endl;
        return false;
    }
    return m_impl->addShip(length, symbol, name);
}

int Game::nShips() const
{
    return m_impl->nShips();
}

int Game::shipLength(int shipId) const
{
    assert(shipId >= 0  &&  shipId < nShips());
    return m_impl->shipLength(shipId);
}

char Game::shipSymbol(int shipId) const
{
    assert(shipId >= 0  &&  shipId < nShips());
    return m_impl->shipSymbol(shipId);
}

string Game::shipName(int shipId) const
{
    assert(shipId >= 0  &&  shipId < nShips());
    return m_impl->shipName(shipId);
}

Player* Game::play(Player* p1, Player* p2, bool shouldPause)
{
    if (p1 == nullptr  ||  p2 == nullptr  ||  nShips() == 0)
        return nullptr;
    Board b1(*this);
    Board b2(*this);
    return m_impl->play(p1, p2, b1, b2, shouldPause);
}

