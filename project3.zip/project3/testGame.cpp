//
//  testGame.cpp
//  project3
//
//  Created by SunYutong on 5/24/17.
//  Copyright © 2017 SunYutong. All rights reserved.
//
//
//#include <stdio.h>
//#include "Game.h"
//#include "globals.h"
//#include <iostream>
//#include <string>
//#include <cassert>
//
//int main()
//{
//    //Game g1(11,11);
//    Game g(10,10);
//    assert(g.rows()==10 && g.cols()==10);
//    Point p1(11,11),p2(0,2), p3(-1,7),p4(-5,-4);
//    Point p5=g.randomPoint();
//    
//    assert(g.isValid(p1)==false && g.isValid(p2)==true && g.isValid(p3)==false && g.isValid(p4)==false && g.isValid(p5)==true);
//    
//    g.addShip(5, 'A', "aircraft");
//    g.addShip(4, 'B', "battleship");
//    g.addShip(3, 'D', "destroyer");
//    assert(g.nShips()==3);
//    assert(g.shipName(0)=="aircraft");
//    assert(g.shipName(1)=="battleship");
//    assert(g.shipName(2)=="destroyer");
//    assert(g.shipLength(0)==5);
//    assert(g.shipLength(1)==4);
//    assert(g.shipLength(2)==3);
//    assert(g.shipSymbol(0)=='A');
//    assert(g.shipSymbol(1)=='B');
//    assert(g.shipSymbol(2)=='D');
//
//
//
//    cout<<"Passed all tests"<<endl;
//    
//}
