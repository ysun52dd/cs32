//
//  Player.cpp
//  project3
//
//  Created by SunYutong on 5/17/17.
//  Copyright © 2017 SunYutong. All rights reserved.
//

#include <stdio.h>
#include "Player.h"
#include <chrono>
#include "Player.h"
#include "Board.h"
#include "Game.h"
#include "globals.h"
#include <iostream>
#include <string>
#include <stack>

using namespace std;

//*********************************************************************
//  AwfulPlayer
//*********************************************************************

class AwfulPlayer : public Player
{
public:
    AwfulPlayer(string nm, const Game& g);
    virtual bool placeShips(Board& b);
    virtual Point recommendAttack();
    virtual void recordAttackResult(Point p, bool validShot, bool shotHit,
                                    bool shipDestroyed, int shipId);
    virtual void recordAttackByOpponent(Point p);
private:
    Point m_lastCellAttacked;
};

AwfulPlayer::AwfulPlayer(string nm, const Game& g)
: Player(nm, g), m_lastCellAttacked(0, 0)
{}

bool AwfulPlayer::placeShips(Board& b)
{
    // Clustering ships is bad strategy
    for (int k = 0; k < game().nShips(); k++)
        if ( ! b.placeShip(Point(k,0), k, HORIZONTAL))
            return false;
    return true;
}

Point AwfulPlayer::recommendAttack()
{
    if (m_lastCellAttacked.c > 0)
        m_lastCellAttacked.c--;
    else
    {
        m_lastCellAttacked.c = game().cols() - 1;
        if (m_lastCellAttacked.r > 0)
            m_lastCellAttacked.r--;
        else
            m_lastCellAttacked.r = game().rows() - 1;
    }
    return m_lastCellAttacked;
}

void AwfulPlayer::recordAttackResult(Point /* p */, bool /* validShot */,
                                     bool /* shotHit */, bool /* shipDestroyed */,
                                     int /* shipId */)
{
    // AwfulPlayer completely ignores the result of any attack
}

void AwfulPlayer::recordAttackByOpponent(Point /* p */)
{
    // AwfulPlayer completely ignores what the opponent does
}

//*********************************************************************
//  HumanPlayer
//*********************************************************************

bool getLineWithTwoIntegers(int& r, int& c)
{
    bool result(cin >> r >> c);
    if (!result)
        cin.clear();  // clear error state so can do more input operations
    cin.ignore(10000, '\n');
    return result;
}

// TODO:  You need to replace this with a real class declaration and
//        implementation.
//typedef AwfulPlayer HumanPlayer;

//This is a concrete class derived from Player. It places ships and recommends attacks based on user input. The isHuman function must return true, so that Game's play function can ensure that a human player doesn't get to see where the opponent's ships are during play. The placeShips and recommendAttack functions must prompt the user for 13 where to place the ships and where to attack, respectively, in the manner of the posted sample program. The recordAttackResult and recordAttackByOpponent probably need not do anything.
class HumanPlayer : public Player
{
public:
    HumanPlayer(string nm, const Game& g);
    virtual bool isHuman() const{ return true; }
    virtual bool placeShips(Board& b);
    virtual Point recommendAttack();
    virtual void recordAttackResult(Point p, bool validShot, bool shotHit,
                                    bool shipDestroyed, int shipId);
    virtual void recordAttackByOpponent(Point p);
private:
    Point m_lastCellAttacked;
};

HumanPlayer::HumanPlayer(string nm, const Game& g)
: Player(nm, g), m_lastCellAttacked(0, 0)
{}

bool HumanPlayer::placeShips(Board& b)
{
    cout<<name()<<" must place "<<game().nShips()<<" ships."<<endl;
    b.clear();
    b.display(false);
    char dir;
    // Clustering ships is bad strategy
    int k=0;
    while(k!=game().nShips())
    {
        cout<<"Enter h or v for direction of "<<game().shipName(k)<<" (length "<<game().shipLength(k)<<") : ";
        cin>>dir;
        if(dir!='h' && dir!='v')
        {
            cout<<"Direction must be h or v."<<endl;
            continue;
        }
        
        //prompt the user until successfully place the ship

        Point p;
        bool placed=false;
        

        while (!placed)
        {
            cout<<"Enter row and column of topmost cell (e.g. 3 5): ";
            placed=getLineWithTwoIntegers(p.r, p.c);
            if(placed)
            {
            if(dir=='h')
            {
                if(b.placeShip(p,k ,HORIZONTAL))
                {
                    b.display(false);
                    placed=true;
                    k++;
                }
                else
                {
                    cout<<"The ship can not be placed there."<<endl;
                    placed=false;
                }
                    
            }
    
            if(dir=='v')
            {
                if(b.placeShip(p,k ,VERTICAL))
                {
                    b.display(false);
                    placed=true;
                    k++;
                }
                else
                {
                    cout<<"The ship can not be placed there."<<endl;
                    placed=false;
                }
            }
        }
        }
    }
    return true;
}

Point HumanPlayer::recommendAttack()
{
    
    //Point p;
    bool valid=false;
    int x,y;
    while(!valid)
    {
        //cout<<"Enter the row and column to attack (e.g, 3 5): ";
        valid=getLineWithTwoIntegers(x, y);
        if(valid)
        {
            m_lastCellAttacked.r=x;
            m_lastCellAttacked.c=y;
        }
    
    }
    return m_lastCellAttacked;

}

void HumanPlayer::recordAttackResult(Point  p , bool  validShot ,
                                     bool shotHit, bool shipDestroyed ,
                                     int  shipId )
{
    // AwfulPlayer completely ignores the result of any attack
}

void HumanPlayer::recordAttackByOpponent(Point p)
{
    // AwfulPlayer completely ignores what the opponent does
}


//*********************************************************************
//  MediocrePlayer
//*********************************************************************

// TODO:  You need to replace this with a real class declaration and
//        implementation.
//typedef AwfulPlayer MediocrePlayer;



class MediocrePlayer : public Player
{
public:
    MediocrePlayer(string nm, const Game& g);
    virtual bool placeShips(Board& b);
    virtual Point recommendAttack();
    virtual void recordAttackResult(Point p, bool validShot, bool shotHit,
                                    bool shipDestroyed, int shipId);
    virtual void recordAttackByOpponent(Point p);
private:
    Point m_lastCellAttacked;
    bool placeAllShips(Board& b,  int shipid);//recursive helper function for placeShips function
    bool state1=true;//keep track of the state 1 and state 2
    bool state1tostate2=false;
    vector<Point> m_attackRecord;
};

MediocrePlayer::MediocrePlayer(string nm, const Game& g)
: Player(nm, g), m_lastCellAttacked(0, 0)
{}
bool MediocrePlayer::placeShips(Board& b)
{
    int count=0;
    while(count<=50)
    {
    //1. First, it must call the block function on the specified board. This will randomly block off about half the positions on the board. No segment of any ship willoccupy one of  these squares.
    b.block();

    //2. Second, you must use a recursive algorithm to place each of the five ships on the board, ensuring that no ship overlaps any other ship and that no ship overlaps a blocked position. You must use the board class’s placeShip function to attempt to place a ship on the board, and unplaceShip to remove it from the board if the position isn’t appropriate. To fit each ship, you may need to place some of them vertically, others horizontally, etc. You may find that after placing some of the ships, you have misallocated the space and need to backtrack, removing the ships you’ve already placed to try a different configuration.
    bool a=placeAllShips(b, 0);
//    Point p;
//    for(int k=0;k<game().nShips();k++)
//    {
//        b.placeShip(p, k, HORIZONTAL);
//    }
    //3. After attempting to place the ships, your function must call the unblock function to remove the blocked squares. This will leave just the ships on your board.
    b.unblock();
        //b.display(false);
    //4. If all ships could be placed, this function returns true. If it is impossible to fit all of the ships on the board, given the set of blocked positions from the first step, then your function must go back to step 1 and try again if it hasn't yet done so 50 times. The function has not returned true after 50 tries, then it must return false.
    if(a)
    return a;
    else
    {
        count++;
        continue;
    }
    }
    //b.display(false);
    return false;
}

bool MediocrePlayer::placeAllShips(Board& b,  int shipid)
{
    //int random=randInt(2);
    Point p;
    if(shipid==game().nShips())
        return true;
    
    //while(!canBePlaced)
   
    for(int i=0; i<game().rows();i++)
    {
        for (int j=0; j<game().cols(); j++)
        {
            p.r=i;
            p.c=j;
//       if(random==0)
//    {      
        
    if(b.placeShip(p, shipid, HORIZONTAL))
    {
        if(placeAllShips(b, shipid+1))
            return true;
        b.unplaceShip(p, shipid, HORIZONTAL);
        
        //b.placeShip(p, shipid+1, VERTICAL);
    }
    //}
//        if(random==1)
//        {
    if(b.placeShip(p, shipid, VERTICAL))
    {
        if(placeAllShips(b, shipid+1))
           return true;
        b.unplaceShip(p, shipid, VERTICAL);
    }
//        }
    else
           continue;
        }
    }
    return false;
    
}
Point MediocrePlayer::recommendAttack()
{
    vector<Point> m_fourStepsAway;
    Point p;
    Point temp=m_lastCellAttacked;
    bool newPoint=false;
    int random;
    while(!newPoint)
    {
    if(state1)
    {
        //1. In state 1, recommendAttack returns a randomly chosen position on the board that has not been chosen before. There are then three possible outcomes when this position is attacked:
        m_lastCellAttacked=game().randomPoint();
        //return m_lastCellAttacked;
        //a. The attack missed. In this case, the player stays in state 1 (so it will again make a random choice for the next recommendation).
        //b. The attack hits a ship, destroying its final undestroyed segment, so the ship is destroyed. In this case, the random attack got lucky and completely destroyed a ship that was almost destroyed earlier. In this case, the player stays in state 1.
        //c. The attack hits a ship, but does not destroy it. In this case, the player switches to state 2 (so will use the algorithm below for the next recommendation)
    }
    if(!state1)
    {
        //2. In state 2, let (r,c) be the position that was hit that caused the transition from state 1 to state 2. In state 2, recommendAttack returns a randomly chosen position drawn from a limited set: the set of valid positions no more than 4 steps away from (r,c) either horizontally or vertically, that have not been chosen before. This set defines a cross around (r,c). For example, assume that in state 1, a shot was fired on position (5,3) that hit a ship, but did not destroy it, resulting in:
        //4 steps up
        if(state1tostate2)
        {
        for(int k=1; k<=4;k++)
        {
            p=temp;
            if(m_lastCellAttacked.r-k>=0 && m_lastCellAttacked.r-k<game().rows())
            {
            p.r=m_lastCellAttacked.r-k;
            m_fourStepsAway.push_back(p);
            }
        }
        //4 steps down
        for(int k=1; k<=4;k++)
        {
            p=temp;
            if(m_lastCellAttacked.r+k>=0 && m_lastCellAttacked.r+k<game().rows())
            {
            p.r=m_lastCellAttacked.r+k;
            m_fourStepsAway.push_back(p);
            }
        }
        //4 steps left
        for(int k=1; k<=4;k++)
        {
            p=temp;
            if(m_lastCellAttacked.c-k>=0 && m_lastCellAttacked.c-k<game().cols())
            {
            p.c=m_lastCellAttacked.c-k;
            m_fourStepsAway.push_back(p);
            }
        }
        //4 steps right
        for(int k=1; k<=4;k++)
        {
            p=temp;
            if(m_lastCellAttacked.c+k>=0 && m_lastCellAttacked.c+k<game().cols())
            {
            p.c=m_lastCellAttacked.c+k;
            m_fourStepsAway.push_back(p);
            }
        }
        }
        
        random=randInt((int)m_fourStepsAway.size());
        m_lastCellAttacked=m_fourStepsAway[random];
        
    }
    //For a MediocrePlayer, these functions work together to implement the following algorithm:
    //0. The Mediocre Player is in one of two states; initially it is in state 1.
        //check whether it is a new point
        newPoint=true;
        for(vector<Point>::iterator ptr=m_attackRecord.begin(); ptr!=m_attackRecord.end();++ptr)
        {
            if((*ptr).r==m_lastCellAttacked.r && (*ptr).c==m_lastCellAttacked.c)
            {
                newPoint=false;
                break;
            }
        }
        
    
   if(!newPoint)
        continue;
    }
    return m_lastCellAttacked;
}

void MediocrePlayer::recordAttackByOpponent(Point p)
{
    
}

void MediocrePlayer::recordAttackResult(Point p, bool validShot, bool shotHit,
                        bool shipDestroyed, int shipId)
{
    m_attackRecord.push_back(p);
        //1. In state 1, recommendAttack returns a randomly chosen position on the board that has not been chosen before. There are then three possible outcomes when this position is attacked:
    if(state1==true)
    {
        //a. The attack missed. In this case, the player stays in state 1 (so it will again make a random choice for the next recommendation).
    if(!shotHit)
        state1=true;
        //b. The attack hits a ship, destroying its final undestroyed segment, so the ship is destroyed. In this case, the random attack got lucky and completely destroyed a ship that was almost destroyed earlier. In this case, the player stays in state 1.
    if(shotHit && shipDestroyed)
        state1=true;
        //c. The attack hits a ship, but does not destroy it. In this case, the player switches to state 2 (so will use the algorithm below for the next recommendation)
    if(shotHit && (!shipDestroyed))
    {
        state1=false;
        state1tostate2=true;
    }
    }
   //2.In state 2
    if(!state1)
    {
    //There are three possible outcomes from the recommended attack:
    //a. The attack missed. In this case, the player stays in state 2.
        if(!shotHit)
            state1=false;
    //b. The attack hits a ship, but does not destroy it. In this case, the player stays in state 2.
        if(shotHit && !shipDestroyed)
            state1=false;
    //c. The attack hits a ship, destroying its final undestroyed segment, so the ship is destroyed. (The ship that was destroyed is likely to be the ship that was hit to cause the transition from state 1 to state 2, but it might have been a different ship that was near that one.) In any event, the player switches to state 1.
        if(shotHit && shipDestroyed)
            state1=true;
    }
    //For a MediocrePlayer, these functions work together to implement the following algorithm:
    //0. The Mediocre Player is in one of two states; initially it is in state 1.
    
    //2. In state 2, let (r,c) be the position that was hit that caused the transition from state 1 to state 2. In state 2, recommendAttack returns a randomly chosen position drawn from a limited set: the set of valid positions no more than 4 steps away from (r,c) either horizontally or vertically, that have not been chosen before. This set defines a cross around (r,c). For example, assume that in state 1, a shot was fired on position (5,3) that hit a ship, but did not destroy it, resulting in:
}

// Remember that Mediocre::placeShips(Board& b) must start by calling
// b.block(), and must call b.unblock() just before returning.

//*********************************************************************
//  GoodPlayer
//*********************************************************************

// TODO:  You need to replace this with a real class declaration and
//        implementation.
class GoodPlayer : public Player
{
public:
    GoodPlayer(string nm, const Game& g);
    virtual bool placeShips(Board& b);
    virtual Point recommendAttack();
    virtual void recordAttackResult(Point p, bool validShot, bool shotHit,
                                    bool shipDestroyed, int shipId);
    virtual void recordAttackByOpponent(Point p);
private:
    Point m_lastCellAttacked;
    Point m_lastHit;
    bool placeAllShips(Board& b,  int shipid);
    int state=1;
    int countHits=0;//count for how many times
    int k=0;//count for the four cells beside the explored cell
    bool Horizontal;
    bool lastHit=false;
    vector<Point> m_fourStepsAway;
    vector<Point> m_oneStepAway;
    vector<Point> m_attackRecord;
    //Board* b;
};

GoodPlayer::GoodPlayer(string nm, const Game& g)
: Player(nm, g), m_lastCellAttacked(0, 0)
{}

bool GoodPlayer::placeShips(Board& b)
{
    int count=0;
    while(count<=50)
    {
        
        b.block();
        
        bool a=placeAllShips(b, 0);
        
        b.unblock();
        
        if(a)
            return a;
        else
        {
            count++;
            continue;
        }
    }
    return false;
}

bool GoodPlayer::placeAllShips(Board& b,  int shipid)
{
    int random=randInt(2);
    Point p;
    if(shipid==game().nShips())
        return true;
    
    for(int i=0; i<game().rows();i++)
    {
        for (int j=0; j<game().cols(); j++)
        {
            p.r=i;
            p.c=j;
            if(random==0)
            {
            
            if(b.placeShip(p, shipid, HORIZONTAL))
            {
                if(placeAllShips(b, shipid+1))
                    return true;
                b.unplaceShip(p, shipid, HORIZONTAL);
                
                //b.placeShip(p, shipid+1, VERTICAL);
            }
            }
            if(random==1)
            {
                if(b.placeShip(p, shipid, VERTICAL))
                {
                if(placeAllShips(b, shipid+1))
                    return true;
                b.unplaceShip(p, shipid, VERTICAL);
                }
            }
            else
                continue;
        }
    }
    return false;
    
}

Point GoodPlayer::recommendAttack()
{
    Point temp(m_lastCellAttacked.r,m_lastCellAttacked.c);
    
    Point p;
    int random=0;
    bool newPoint=false;
    //state 1:
    while(!newPoint)
    {
    if(state==1)
    {
        //generate a random point
        m_lastCellAttacked=game().randomPoint();
    }
    //state 2:
    if(state==2)
    {
        //1 step up
        p=temp;
        if(temp.r-1>=0 && temp.r-1<game().rows())
        {
            p.r=temp.r-1;
            m_oneStepAway.push_back(p);
        }
        //1 step down
        p=temp;
        if(temp.r+1>=0 && temp.r+1<game().rows())
        {
            p.r=temp.r+1;
            m_oneStepAway.push_back(p);
        }
        
        //1 step left
        p=temp;
        if(temp.c-1>=0 && temp.c-1<game().cols())
        {
            p.c=temp.c-1;
            m_oneStepAway.push_back(p);
        }
        //1 step right
        p=temp;
        if(temp.c+1>=0 && temp.c+1<game().cols())
        {
            p.c=temp.c+1;
            m_oneStepAway.push_back(p);
        }
        //random=randInt((int)m_fourStepsAway.size());
        k=randInt((int)m_oneStepAway.size());
            m_lastCellAttacked=m_oneStepAway[k];
        
        //decide the dirction
        if(m_lastCellAttacked.r==temp.r+1 || m_lastCellAttacked.r==temp.r-1)
            Horizontal=false;//dirction is vertical
        if(m_lastCellAttacked.c==temp.c+1 || m_lastCellAttacked.c==temp.c-1)
            Horizontal=true;
        
    }
    //stat 4:
    if(state==4)
    {
        //
        Horizontal=!Horizontal;
        if(Horizontal)
        {
            int r=randInt(2);
            if(r==0)
                m_lastCellAttacked.c--;
            if(r==1)
                m_lastCellAttacked.c++;
        }
        if(!Horizontal)
        {
            int r=randInt(2);
            if(r==0)
                m_lastCellAttacked.r--;
            if(r==1)
                m_lastCellAttacked.r++;
        }
       }
    //state 3:
    if(state==3)
    {
        if(Horizontal)
        {
            //4 steps left
            for(int k=1; k<=4;k++)
            {
                p=temp;
                if(m_lastHit.c-k>=0 && m_lastHit.c-k<game().cols())
                {
                p.c=m_lastHit.c-k;
                m_fourStepsAway.push_back(p);
                }
            }
            //4 steps right
            for(int k=1; k<=4;k++)
            {
                p=temp;
                if(m_lastHit.c+k>=0 &&m_lastHit.c+k<game().cols())
                {
                p.c=m_lastHit.c+k;
                m_fourStepsAway.push_back(p);
                }
            }
            random=randInt((int)m_fourStepsAway.size());
            m_lastCellAttacked=m_fourStepsAway[random];

        }
        
        if(!Horizontal)
        {
            //4 steps up
            for(int k=1; k<=4;k++)
            {
                p=temp;
                if(m_lastHit.r-k>=0 &&m_lastHit.r-k<game().rows())
                {
                p.r=m_lastHit.r-k;
                m_fourStepsAway.push_back(p);
                }
            }
            //4 steps down
            for(int k=1; k<=4;k++)
            {
                p=temp;
                if(m_lastHit.c+k>=0 &&m_lastHit.c+k<game().rows())
                {
                p.r=m_lastHit.r+k;
                m_fourStepsAway.push_back(p);
                }
            }
            random=randInt((int)m_fourStepsAway.size());
            m_lastCellAttacked=m_fourStepsAway[random];

        }
    }
    
    if(state==5)
    {
        random=randInt((int)m_fourStepsAway.size());
        //random++;
        m_lastCellAttacked=m_fourStepsAway[random];
    }
    //For a MediocrePlayer, these functions work together to implement the following algorithm:
    //0. The Mediocre Player is in one of two states; initially it is in state 1.
        
        //check if it is a new point
        newPoint=true;
        for(vector<Point>::iterator ptr=m_attackRecord.begin(); ptr!=m_attackRecord.end();++ptr)
        {
            if((*ptr).r==m_lastCellAttacked.r && (*ptr).c==m_lastCellAttacked.c)
            {
                newPoint=false;
                break;
            }
            
        }
        
        
        if(!newPoint)
            continue;
    
    if(m_lastCellAttacked.r<0 || m_lastCellAttacked.c<0 || m_lastCellAttacked.r>=game().rows() ||m_lastCellAttacked.c>=game().cols())
        continue;
    }
        
        return m_lastCellAttacked;

}

void GoodPlayer::recordAttackResult(Point p, bool validShot, bool shotHit,
                        bool shipDestroyed, int shipId)
{
     m_attackRecord.push_back(p);
    //state, no cell explored
    if(!shotHit && countHits==0)
        state=1;
    
    //return to state 1, the whole ship destroyed
    else if(shotHit && shipDestroyed)
    {
        state=1;
        
        countHits=0;
       
    }
    
    //state 2 (first cell explored)
    else if(shotHit && (!shipDestroyed) && countHits==0)
    {
        state=2;
        countHits++;
        m_lastHit=m_lastCellAttacked;
    }
    //did not hit the second cell,dirction known, state 4
    else if(!shotHit && (!shipDestroyed) && countHits==1)
    {
        state=4;
        k++;
    }
    //state 3 (2 cells explored, dirction known)
    else if(shotHit && (!shipDestroyed) && countHits==1)
    {
        state=3;
        countHits++;
    }
    //did not hit the third cell, state 5
    else if(!shotHit && !shipDestroyed && countHits>=2)
    {
        state=5;
    }


}
void GoodPlayer::recordAttackByOpponent(Point p)
{
    
}

//*********************************************************************
//  createPlayer
//*********************************************************************

Player* createPlayer(string type, string nm, const Game& g)
{
    static string types[] = {
        "human", "awful", "mediocre", "good"
    };
    
    int pos;
    for (pos = 0; pos != sizeof(types)/sizeof(types[0])  &&
         type != types[pos]; pos++)
        ;
    switch (pos)
    {
        case 0:  return new HumanPlayer(nm, g);
        case 1:  return new AwfulPlayer(nm, g);
        case 2:  return new MediocrePlayer(nm, g);
        case 3:  return new GoodPlayer(nm, g);
        default: return nullptr;
    }
}

class Timer
{
public:
    Timer()
    {
        start();
    }
    void start()
    {
        m_time = std::chrono::high_resolution_clock::now();
    }
    double elapsed() const
    {
        std::chrono::duration<double,std::milli> diff =
        std::chrono::high_resolution_clock::now() - m_time;
        return diff.count();
    }
private:
    std::chrono::high_resolution_clock::time_point m_time;
};

