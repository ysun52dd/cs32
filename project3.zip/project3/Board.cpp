//
//  Board.cpp
//  project3
//
//  Created by SunYutong on 5/17/17.
//  Copyright © 2017 SunYutong. All rights reserved.
//

#include "Board.h"
#include "Game.h"
#include "globals.h"
#include <iostream>
#include <list>
#include <vector>

using namespace std;
class BoardImpl
{
public:
    BoardImpl(const Game& g);
    void clear();
    void block();
    void unblock();
    bool placeShip(Point topOrLeft, int shipId, Direction dir);
    bool unplaceShip(Point topOrLeft, int shipId, Direction dir);
    void display(bool shotsOnly) const;
    bool attack(Point p, bool& shotHit, bool& shipDestroyed, int& shipId);
    bool allShipsDestroyed() const;

private:
    // TODO:  Decide what private members you need.  Here's one that's likely
    //        to be useful:
    const Game& m_game;
    
    int m_row,m_col; //numbers of rows and columns in the board
        
    class Ship
    {
    public:
        int m_length;
        char m_symbol;
        string m_name;
        int id;
        //int n_segment;
        
        Ship(int length, char symbol, string name)
        :m_length(length),m_symbol(symbol),m_name(name)
        { }
        
    };
    vector<Ship> placedShip;
    //Point m_board[][MAXCOLS];
    class Coord
    {
    public:
        Coord()
        {}
        
        Coord(int r,int c, char d)
        :c_row(r),c_col(c),p(r,c), display(d)
        { }
    
        int c_row;
        int c_col;
        Point p;
        char display;
    };

    Coord m_coord[MAXROWS][MAXCOLS];//an 2D array of Coord to record information of each point on the board
    
};

BoardImpl::BoardImpl(const Game& g)
: m_game(g),m_row(g.rows()),m_col(g.cols())
{
    //Coord c(0,0,' ');
    //m_coord[0][0]=c;
    //for(int k=1; k<MAXCOLS+1;k++)
    //{
    //    Coord c(0,k,'0'+k-1);
    //m_coord[0][k]=c;
    //}
    //for(int k=1;k<MAXROWS+1;k++)
    //{
    //    Coord c(k,0,'0'+k-1);
    //    m_coord[k][0]=c;
    //}
    for(int j=0;j<MAXCOLS;j++)
    {
        for(int i=0;i<MAXROWS;i++)
        {
            Coord c(i,j,EMPTY);
            m_coord[i][j]=c;
        }
    }
    // This compiles, but may not be correct
}

void BoardImpl::clear()
{
    //for(int k=1; k<MAXCOLS+1;k++)
    //{
    //    Coord c(0,k,'0'+k-1);
    //    m_coord[0][k]=c;
    //}
    //
    //for(int k=1;k<MAXROWS+1;k++)
    //{
    //    Coord c(k,0,'0'+k-1);
    //    m_coord[k][0]=c;
    //}
    //fill the board with '.' to clear the board
    
    for(int j=0;j<MAXCOLS;j++)
    {
        for(int i=0;i<MAXROWS;i++)
        {
            m_coord[i][j].display= EMPTY;
        }
    }

    
    // This compiles, but may not be correct
}

void BoardImpl::block()
{
    // Block cells with 50% probability
    for (int r = 0; r < m_game.rows(); r++)
        for (int c = 0; c < m_game.cols(); c++)
            if (randInt(2) == 0)
            {
                Coord m(r,c,BLOCK);
                m_coord[r][c]=m;
                 // TODO:  Replace this with code to block cell (r,c)
            }
}
//This function blocks about half the positions on the board. This function will be used
//only by the MediocrePlayer when placing ships on the board at the start of play. If a
//position is blocked, then that player may not place a ship that occupies that location.
void BoardImpl::unblock()
{
    for (int r = 0; r < m_game.rows(); r++)
        for (int c = 0; c < m_game.cols(); c++)
        {
            if(m_coord[r][c].display==BLOCK)
            {
            //Coord m(r,c+1,EMPTY);
            m_coord[r][c].display=EMPTY;
            }
            
             // TODO:  Replace this with code to unblock cell (r,c) if blocked
        }
}

bool BoardImpl::placeShip(Point topOrLeft, int shipId, Direction dir)
{
    /*
     This function attempts to place the specified ship at the specified coordinate, in the
     specified direction. The parameter topOrLeft specifies the topmost segment of the ship if
     dir is VERTICAL, or the leftmost segment if dir is HORIZONTAL. The parameter
     shipId is the ship ID number. This function returns false if the ship cannot be placed
     because:
     1. The shipId is invalid
     */
    if(shipId>=m_game.nShips()||shipId<0)
        return false;
    
     //2. The ship would be partly or fully outside the board.
    if((topOrLeft.r+m_game.shipLength(shipId)-1>=m_row && dir==VERTICAL)||(topOrLeft.c+m_game.shipLength(shipId)-1>=m_col && dir==HORIZONTAL))
        return false;
    if(topOrLeft.r>=m_row||topOrLeft.r<0||topOrLeft.c>=m_col||topOrLeft.c<0)
        return false;
     //3. The ship would overlap an already-placed ship.
     //4. The ship would overlap one or more positions that were blocked by a previous
     //call to the block function.
    if(dir==VERTICAL)
    {
        for(int i=topOrLeft.r;i<topOrLeft.r+m_game.shipLength(shipId);i++)
        {
            if(m_coord[i][topOrLeft.c].display!=EMPTY)
                return false;
        }
    }
    if(dir==HORIZONTAL)
    {
        for(int j=topOrLeft.c;j<topOrLeft.c+m_game.shipLength(shipId);j++)
        {
            if(m_coord[topOrLeft.r][j].display!=EMPTY)
                return false;
        }
    }
     
    
    //5. The ship with that ship ID has previously been placed on this Board and not
     //yet been unplaced since its most recent placement.
    for(vector<Ship>::iterator p=placedShip.begin(); p!=placedShip.end();p++)
    {
       
        if(p->id==shipId)
            return false;
            
    }

    //If this function returns false, then the board must remain unchanged (i.e. no part of the ship may remain on the board upon failure). If this function successfully places the ship,the board is updated to reflect that, and the function returns true.
    
    //push the ship into the placedShip list
    Ship s(m_game.shipLength(shipId),m_game.shipSymbol(shipId),m_game.shipName(shipId));
    s.id=shipId; //denote the shipId into the ship object
    placedShip.push_back(s); //push the placed ship into the placedShip list
    
    //place the ship on m_coord's display
    if(dir==VERTICAL)
    {
        for(int i=topOrLeft.r;i<topOrLeft.r+m_game.shipLength(shipId);i++)
        {
            m_coord[i][topOrLeft.c].display=m_game.shipSymbol(shipId);
        }
    }
    if(dir==HORIZONTAL)
    {
        for(int j=topOrLeft.c;j<topOrLeft.c+m_game.shipLength(shipId);j++)
        {
            m_coord[topOrLeft.r][j].display=m_game.shipSymbol(shipId);
        }
    }

    return true;
}

//This function attempts to remove the specified ship from the board, so the positions it occupied may be used to place other ships. The parameters are the same as for placeShip. This function returns false if the ship cannot be removed because:

//If this function returns false, then the board must remain unchanged (i.e. no part of the ship may be removed upon failure). If this function successfully removes the ship, the board is updated to reflect that, and the function returns true.
bool BoardImpl::unplaceShip(Point topOrLeft, int shipId, Direction dir)
{
    //1. Return false if the shipId is invalid
    if(shipId>=m_game.nShips()||shipId<0)
        return false;
    //if the ship is not on the board
    bool find=false;
    for(vector<Ship>::iterator p=placedShip.begin(); p!=placedShip.end();++p)
    {
        if(p->id==shipId)
            find=true;
    }
    if(!find)
        return false;
    
    //2. The board does not contain the entire ship at the indicated locations.
    
    if(dir==VERTICAL)
    {
        for(int i=topOrLeft.r;i<m_game.shipLength(shipId)+topOrLeft.r;i++)
        {
            if(m_coord[i][topOrLeft.c].display!=m_game.shipSymbol(shipId))
                return false;
        }
    }
    if(dir==HORIZONTAL)
    {
        for(int j=topOrLeft.c;j<m_game.shipLength(shipId)+topOrLeft.c;j++)
        {
            if(m_coord[topOrLeft.r][j].display!=m_game.shipSymbol(shipId))
                return false;
        }
    }
    //remove the ship in the list placedShip
    for(vector<Ship>::iterator p=placedShip.begin(); p!=placedShip.end();)
    {
        if(p->id==shipId)
        {
            p=placedShip.erase(p);
            //break;
        }
        else
            p++;
        
    }
    //remove the ship on m_coord
    
    if(dir==VERTICAL)
    {
        for(int i=topOrLeft.r;i<topOrLeft.r+m_game.shipLength(shipId);i++)
        {
            m_coord[i][topOrLeft.c].display=EMPTY;
        }
    }
    if(dir==HORIZONTAL)
    {
        for(int j=topOrLeft.c;j<topOrLeft.c+m_game.shipLength(shipId);j++)
        {
            m_coord[topOrLeft.r][j].display=EMPTY;
        }
    }

    return true; // This compiles, but may not be correct
}


void BoardImpl::display(bool shotsOnly) const
{
    //print the coordinate of columns
    cout<<' ';
    for(int k=0;k<m_col;k++)
    {
        cout<<' ';
        cout<<k;
    }
    cout<<endl;
    for(int i=0;i<m_row;i++)
    {
        //print the coordinate of rows
        cout<<i<<' ';
        for(int j=0;j<m_col;j++)
        {
            //If the shotOnly parameter is false, use the ship's symbol to display an undamaged ship segment.
            if(!shotsOnly)
            cout<<m_coord[i][j].display<<' ';
            
            // if the shotsOnly parameter is true, show a period to display an undamaged ship segment.
            if(shotsOnly)
            {
                bool isShip=false;
                for(int k=0;k<m_game.nShips();k++)
                {
                    if(m_coord[i][j].display==m_game.shipSymbol(k))//display '.' if there is a ship symbol
                    {
                        cout<<EMPTY<<' ';
                        isShip=true;
                        break;
                    }
                    
                    
                }
                if(!isShip)
                    cout<<m_coord[i][j].display<<' ';
            }
        }
        cout<<endl;
    }
        
    //This function displays the board, using the following format:
    //1. First line: The function must print two spaces followed by the digits for each column, starting at 0, followed by a newline. You may assume there will be no more than 10 columns.
    //2. Remaining lines: The function must print a digit specifying the row number, starting at 0, followed by a space, followed by the contents of the current row, followed by a newline. You may assume there will be no more than 10 rows. In each of the positions of the row, use the following characters to represent the playing field:
    //a. If the shotOnly parameter is false, use the ship's symbol to display an undamaged ship segment; if the shotsOnly parameter is true, show a period to display an undamaged ship segment.
    //b. Use an X character to display any damaged ship segment.
    //c. Use a period to display water where no attack has been made.
    //d. Use a lower case letter o character to display water where an attack has been made that missed a ship.
    // This compiles, but may not be correct
}

bool BoardImpl::attack(Point p, bool& shotHit, bool& shipDestroyed, int& shipId)
{
    //initialize shotHit to false. Otherwise the shotHit parameter must be set to false.
    shotHit=false;
    shipDestroyed=false;
    //The function must return false if the attack is invalid (the attack point is outside of the board area, or an attack is made on a previously attacked location)
    if(p.r>=m_row||p.r<0||p.c>=m_col||p.c<0||m_coord[p.r][p.c].display==ATTACKED)
    {
        
        return false;
    }
    //If any undamaged segment of a ship is at position p on the board, then the shotHit parameter must be set to true, and the segment must henceforth be considered a damaged segment.
    //int l=0;
    int idDestroyed=0;
    
    for(vector<Ship>::iterator ptr=placedShip.begin(); ptr!=placedShip.end();++ptr)
    {
        if(m_coord[p.r][p.c].display==ptr->m_symbol)
        {
            shotHit=true;
            ptr->m_length--;
            //l=ptr->m_length;
            idDestroyed=ptr->id;
            m_coord[p.r][p.c].display=ATTACKED;
            if(ptr->m_length==0)
            {
                shipDestroyed=true;
                shipId=idDestroyed;
            }

            break;
        }
    }
    if(!shotHit)
        m_coord[p.r][p.c].display=MISS;
    
    //If this specific attack destroyed the last undamaged segment of a ship, then the shipDestroyed parameter must be set to true and the shipId parameter must be set to the ship ID of the ship that was destroyed;
    return true; // This compiles, but may not be correct
}
//This function is used to submit an attack against the board. The function must return false if the attack is invalid (the attack point is outside of the board area, or an attack is made on a previously attacked location).
//(*)The function returns true if the attack is valid regardless of whether or not any ship is damaged. If any undamaged segment of a ship is at position p on the board, then the shotHit parameter must be set to true, and the segment must henceforth be considered a damaged segment. Otherwise the shotHit parameter must be set to false.  otherwise the shipDestroyed parameter must be set to false and shipId must be left unchanged.It's up to you whether to set to some value or leave unchanged:
//1. shotHit, shipDestroyed, and shipId if the attack is invalid
//2. shipDestroyed and shipId if the attack missed

bool BoardImpl::allShipsDestroyed() const
{
    bool allDestroyed=true;
    for(int k=0; k<placedShip.size();k++)
    {
        if(placedShip[k].m_length!=0)
            allDestroyed=false;
    }
    
    return allDestroyed; // This compiles, but may not be correct
}
//This function returns true if all ships have been completely destroyed on the current board and false otherwise. (If this is true, it means that the player who was attacking that board has won the game.) As with the Game class, the real work will be implementing the auxiliary class BoardImpl in Board.cpp. Other than Board.cpp, no source file that you turn in may contain the name BoardImpl. Thus, your other classes must not directly instantiate or even mention BoardImpl in their code. They may use the Board class that we provide (which indirectly uses your BoardImpl class).


//******************** Board functions ********************************

// These functions simply delegate to BoardImpl's functions.
// You probably don't want to change any of this code.

Board::Board(const Game& g)
{
    m_impl = new BoardImpl(g);
}

Board::~Board()
{
    delete m_impl;
}

void Board::clear()
{
    m_impl->clear();
}

void Board::block()
{
    return m_impl->block();
}

void Board::unblock()
{
    return m_impl->unblock();
}

bool Board::placeShip(Point topOrLeft, int shipId, Direction dir)
{
    return m_impl->placeShip(topOrLeft, shipId, dir);
}

bool Board::unplaceShip(Point topOrLeft, int shipId, Direction dir)
{
    return m_impl->unplaceShip(topOrLeft, shipId, dir);
}

void Board::display(bool shotsOnly) const
{
    m_impl->display(shotsOnly);
}

bool Board::attack(Point p, bool& shotHit, bool& shipDestroyed, int& shipId)
{
    return m_impl->attack(p, shotHit, shipDestroyed, shipId);
}

bool Board::allShipsDestroyed() const
{
    return m_impl->allShipsDestroyed();
}


/*class BoardImpl{
    
public:
    int m_row;
    int m_col;
    class Ship
    {
    public:
        int m_length;
        char m_symbol;
        string m_name;
        
        
        Ship(int length, char symbol, string name)
        :m_length(length),m_symbol(symbol),m_name(name)
        { }
        
    };
    vector<Ship> m_ship;
    Point m_board[][MAXCOLS];
    
};
*/
/*Board::Board(const Game& g)

{
    ptr->m_row=g.rows();
    ptr->m_col=g.cols();
    ptr->m_ship=g.ptr->m_ship;
}*/
 /*Initialize a board. The parameter g refers to the game the board is being used in. Board
 member functions that need to know the number of rows or columns or the characteristics
 of ships will presumably find out from the game object the board was constructed with.
 
*/
/*void Board::clear()
{
    for(int i=0; i<ptr->m_row; i++)
    {
        for( int j=0; j<ptr->m_col; j++)
           Point m_board[i][j]=Point(i,j);
    }
}
 //This function clears the board so it is empty, ready to be populated with ships.
 
void Board::block()
{
}
 //This function blocks about half the positions on the board. This function will be used
 //only by the MediocrePlayer when placing ships on the board at the start of play. If a
 //position is blocked, then that player may not place a ship that occupies that location.
void Board::unblock()
{
    
}
 //This function unblocks all the blocked positions on the board. This function will be used
 //only by the MediocrePlayer, after placing ships on the board, but before the start of play.
bool Board::placeShip(Point topOrLeft, int shipId, Direction dir)
{
    
}*/
/*This function attempts to place the specified ship at the specified coordinate, in the
 specified direction. The parameter topOrLeft specifies the topmost segment of the ship if
 dir is VERTICAL, or the leftmost segment if dir is HORIZONTAL. The parameter
 shipId is the ship ID number. This function returns false if the ship cannot be placed
 because:
 1. The shipId is invalid
 2. The ship would be partly or fully outside the board.
 3. The ship would overlap an already-placed ship.
 4. The ship would overlap one or more positions that were blocked by a previous
 call to the block function.
 5. The ship with that ship ID has previously been placed on this Board and not
 yet been unplaced since its most recent placement.*/
//bool Board::unplaceShip(Point topOrLeft, int shipId, Direction dir)

    

/*This function attempts to remove the specified ship from the board, so the positions it
 occupied may be used to place other ships. The parameters are the same as for placeShip.
 This function returns false if the ship cannot be removed because:
 1. The shipId is invalid
 2. The board does not contain the entire ship at the indicated locations.
 If this function returns false, then the board must remain unchanged (i.e. no part of the
 ship may be removed upon failure). If this function successfully removes the ship, the
 board is updated to reflect that, and the function returns true.*/
//void Board::display(bool shotsOnly) const


/*This function displays the board, using the following format:
 1. First line: The function must print two spaces followed by the digits for each
 column, starting at 0, followed by a newline. You may assume there will be no
 more than 10 columns.
 2. Remaining lines: The function must print a digit specifying the row number,
 starting at 0, followed by a space, followed by the contents of the current row,
 followed by a newline. You may assume there will be no more than 10 rows. In
 each of the positions of the row, use the following characters to represent the
 playing field:
 a. If the shotOnly parameter is false, use the ship's symbol to display an
 undamaged ship segment; if the shotsOnly parameter is true, show a
 period to display an undamaged ship segment.
 b. Use an X character to display any damaged ship segment.
 c. Use a period to display water where no attack has been made.
 d. Use a lower case letter o character to display water where an attack has
 been made that missed a ship.*/
//bool Board::attack(Point p, bool& shotHit, bool& shipDestroyed, int& shipId)

    

/*This function is used to submit an attack against the board. The function must return
false if the attack is invalid (the attack point is outside of the board area, or an attack is
                                made on a previously attacked location). The function returns true if the attack is valid,
regardless of whether or not any ship is damaged.
If any undamaged segment of a ship is at position p on the board, then the shotHit
parameter must be set to true, and the segment must henceforth be considered a damaged
segment. Otherwise the shotHit parameter must be set to false.
If this specific attack destroyed the last undamaged segment of a ship, then the
shipDestroyed parameter must be set to true and the shipId parameter must be set to the
ship ID of the ship that was destroyed; otherwise the shipDestroyed parameter must be
set to false and shipId must be left unchanged.
It's up to you whether to set to some value or leave unchanged:
1. shotHit, shipDestroyed, and shipId if the attack is invalid
2. shipDestroyed and shipId if the attack missed*/
//bool Board::allShipsDestroyed() const


/*This function returns true if all ships have been completely destroyed on the current
 board and false otherwise. (If this is true, it means that the player who was attacking that
 board has won the game.)
 As with the Game class, the real work will be implementing the auxiliary class
 BoardImpl in Board.cpp. Other than Board.cpp, no source file that you turn in may
 contain the name BoardImpl. Thus, your other classes must not directly instantiate or
 even mention BoardImpl in their code. They may use the Board class that we provide
 (which indirectly uses your BoardImpl class).*/
